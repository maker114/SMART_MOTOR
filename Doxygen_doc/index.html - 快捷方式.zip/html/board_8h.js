var board_8h =
[
    [ "KEY1", "board_8h.html#af709a8c6c00929607ff2bb1f35e14754", null ],
    [ "KEY2", "board_8h.html#a28139a703782c6706c0c53bda00572d3", null ],
    [ "KEY3", "board_8h.html#a110ce38bd8be5f986c9032a3535156f7", null ],
    [ "LED", "board_8h.html#aeb7a7ba1ab7e0406f1b5ab36d579f585", null ]
];
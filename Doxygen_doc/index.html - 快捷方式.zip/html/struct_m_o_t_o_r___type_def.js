var struct_m_o_t_o_r___type_def =
[
    [ "PID_GoalSpeed", "struct_m_o_t_o_r___type_def.html#ae92508792bc1fd2e0b41f8e44884be27", null ],
    [ "PID_I_MAX", "struct_m_o_t_o_r___type_def.html#ad522bf1ad47d7b8689bf50f8e0d7507a", null ],
    [ "PID_Integral", "struct_m_o_t_o_r___type_def.html#ad3055460ab3f465e12ec6ec203ceea85", null ],
    [ "PID_KD", "struct_m_o_t_o_r___type_def.html#abb3952aa7d2656ed304d569f86b92178", null ],
    [ "PID_KI", "struct_m_o_t_o_r___type_def.html#a08359f725445fb251a981993bf69c6eb", null ],
    [ "PID_KP", "struct_m_o_t_o_r___type_def.html#a9d2d2539809b42de760a2359fcf688a8", null ],
    [ "PID_LastError", "struct_m_o_t_o_r___type_def.html#afd34c7d8fbe486aa79fba8c80c303af0", null ],
    [ "PWMvalue", "struct_m_o_t_o_r___type_def.html#af6af3155e4eb01becc53d5ecf84518b1", null ],
    [ "Speed", "struct_m_o_t_o_r___type_def.html#aaf30cde4fff92dd5364976dd0bfd7298", null ]
];
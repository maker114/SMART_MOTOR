var indexSectionsWithContent =
{
  0: "abdfiklmprstuw串发定总数电颜",
  1: "fm",
  2: "bmuw",
  3: "flmtuw",
  4: "abfimps",
  5: "l",
  6: "ls",
  7: "dklmw",
  8: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "结构体",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "枚举",
  6: "枚举值",
  7: "宏定义",
  8: "页"
};


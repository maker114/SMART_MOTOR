var struct_fast_response_filter =
[
    [ "alpha", "struct_fast_response_filter.html#ad6cfe8c02f6c3b69fd09c651fcc7ee94", null ],
    [ "buffer", "struct_fast_response_filter.html#a33756aff30bf4fe8ff229b755767161f", null ],
    [ "index", "struct_fast_response_filter.html#af31b218cbd6e2e9666d1c5d9f462d640", null ],
    [ "prev_value", "struct_fast_response_filter.html#aa18f5dadb74e2d295d39aa06a55e47a9", null ]
];
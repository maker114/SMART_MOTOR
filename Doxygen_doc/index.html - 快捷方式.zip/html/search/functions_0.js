var searchData=
[
  ['filter_5finit_0',['filter_init',['../motor_8h.html#a3da956b1aa9802bb2eab8f1abf668b87',1,'Filter_Init(FastResponseFilter *filter, float alpha, float init_value):&#160;motor.c'],['../motor_8c.html#a3da956b1aa9802bb2eab8f1abf668b87',1,'Filter_Init(FastResponseFilter *filter, float alpha, float init_value):&#160;motor.c']]],
  ['filter_5fprocess_1',['filter_process',['../motor_8h.html#a344389181533718b0965a8df949077e5',1,'Filter_Process(FastResponseFilter *filter, float raw_value):&#160;motor.c'],['../motor_8c.html#a344389181533718b0965a8df949077e5',1,'Filter_Process(FastResponseFilter *filter, float raw_value):&#160;motor.c']]]
];

var searchData=
[
  ['motor_5foperatingmode_0',['MOTOR_OperatingMode',['../motor_8h.html#ae8af17ce114d19cf4616af34313f2c4d',1,'motor.h']]],
  ['motor_5forientation_1',['MOTOR_Orientation',['../motor_8h.html#ae38aa0e17231c915570c88ff6ed52c03',1,'motor.h']]],
  ['motorstructure_5fa_2',['MotorStructure_A',['../motor_8c.html#a6c711ce98ed96187d842062a5ff35eb1',1,'motor.c']]],
  ['motorstructure_5fb_3',['MotorStructure_B',['../motor_8c.html#aeff298f91376572d1bffa99414755ad0',1,'motor.c']]]
];

var searchData=
[
  ['filter_5fa_0',['filter_A',['../motor_8c.html#a02b72a8107e17af08faa7120b3278de0',1,'motor.c']]],
  ['filter_5fb_1',['filter_B',['../motor_8c.html#aff426ab4c5bbc38c8baaf18477317f52',1,'motor.c']]]
];

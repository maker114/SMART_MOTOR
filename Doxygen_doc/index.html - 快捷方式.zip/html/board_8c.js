var board_8c =
[
    [ "Board_BEEP_ActiveMs", "board_8c.html#a89a225d345c395378ab68410fe1106ff", null ],
    [ "Board_BEEP_ContinuousActive", "board_8c.html#acd3b3703c394450104094f0f6fd89054", null ],
    [ "Board_Init", "board_8c.html#ae8d2d761b984f48c3dbb27dd32a8c119", null ],
    [ "Board_KeyScan", "board_8c.html#ab02f9e7316c2c1b92333ea0d3abd098a", null ],
    [ "Board_LED_Toggle", "board_8c.html#a9bf3b36e2cff1be4f76547a9e7453067", null ]
];
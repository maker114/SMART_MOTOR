var searchData=
[
  ['power_5freg_0',['Power_Reg',['../_i_n_a226_8h.html#a9fac6cca7c32cfd970fff62c573b94c0',1,'INA226.h']]]
];

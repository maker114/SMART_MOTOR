var searchData=
[
  ['fastresponsefilter_0',['FastResponseFilter',['../struct_fast_response_filter.html',1,'']]],
  ['filter_5fa_1',['filter_A',['../motor_8c.html#a02b72a8107e17af08faa7120b3278de0',1,'motor.c']]],
  ['filter_5fb_2',['filter_B',['../motor_8c.html#aff426ab4c5bbc38c8baaf18477317f52',1,'motor.c']]],
  ['filter_5finit_3',['filter_init',['../motor_8h.html#a3da956b1aa9802bb2eab8f1abf668b87',1,'Filter_Init(FastResponseFilter *filter, float alpha, float init_value):&#160;motor.c'],['../motor_8c.html#a3da956b1aa9802bb2eab8f1abf668b87',1,'Filter_Init(FastResponseFilter *filter, float alpha, float init_value):&#160;motor.c']]],
  ['filter_5fprocess_4',['filter_process',['../motor_8h.html#a344389181533718b0965a8df949077e5',1,'Filter_Process(FastResponseFilter *filter, float raw_value):&#160;motor.c'],['../motor_8c.html#a344389181533718b0965a8df949077e5',1,'Filter_Process(FastResponseFilter *filter, float raw_value):&#160;motor.c']]]
];

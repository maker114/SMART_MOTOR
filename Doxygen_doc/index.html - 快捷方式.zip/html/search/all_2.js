var searchData=
[
  ['direction_5fain1_0',['Direction_AIN1',['../motor_8h.html#aafa2236648124d8aed616b29237527ef',1,'motor.h']]],
  ['direction_5fain2_1',['Direction_AIN2',['../motor_8h.html#aa92cdccb4e3364f7ecce7e66c9912712',1,'motor.h']]],
  ['direction_5fbin1_2',['Direction_BIN1',['../motor_8h.html#ad6deb06b00049067997c769558abc376',1,'motor.h']]],
  ['direction_5fbin2_3',['Direction_BIN2',['../motor_8h.html#a6e86e051120cbfb4f9b15046984479df',1,'motor.h']]],
  ['direction_5fgroup_5fa_4',['Direction_Group_A',['../motor_8h.html#a3b0445d7c2f456c1820f6eecb5598ec7',1,'motor.h']]],
  ['direction_5fgroup_5fb_5',['Direction_Group_B',['../motor_8h.html#a72f6e6ae15c3121232fa76cee8b2cc5d',1,'motor.h']]],
  ['direction_5ftim_5fa_6',['Direction_TIM_A',['../motor_8h.html#af6822b955457f3d025b5c5a6314676f5',1,'motor.h']]],
  ['direction_5ftim_5fb_7',['Direction_TIM_B',['../motor_8h.html#a88747e31a21716014d01d766e2b55fbb',1,'motor.h']]]
];

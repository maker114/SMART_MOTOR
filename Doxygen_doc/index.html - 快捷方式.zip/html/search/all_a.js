var searchData=
[
  ['speed_0',['Speed',['../struct_m_o_t_o_r___type_def.html#aaf30cde4fff92dd5364976dd0bfd7298',1,'MOTOR_TypeDef']]],
  ['sum_1',['SUM',['../usart__link_8h.html#a68e533ebd478ec5917d059459f4962bda82c030bf31e2d975e6a85cf67ba88bb4',1,'usart_link.h']]]
];

var files_dup =
[
    [ "HARDWARE", "dir_06a443c98342f337bff9d9dc419b3392.html", "dir_06a443c98342f337bff9d9dc419b3392" ]
];